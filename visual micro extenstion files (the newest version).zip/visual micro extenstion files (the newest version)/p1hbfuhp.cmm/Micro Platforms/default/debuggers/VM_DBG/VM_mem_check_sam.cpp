#if defined(ESP8266)
#if VM_DEBUG_MEM_CHECK == VM_DEBUG_ENABLE
#include <Arduino.h>
#include "esp.h"
#include "VM_mem_check.h"
int _VM_freeMemory()
{
	return ESP.getFreeHeap();
}
#endif

#elif defined(ARDUINO_ARCH_SAMD)||defined(ARDUINO_ARCH_SAM)||defined(ARDUINO_ARCH_ARC32)

#if (ARDUINO >= 100)
#include <Arduino.h>
#else
#include <WProgram.h>
#endif

#if VM_DEBUG_MEM_CHECK == VM_DEBUG_ENABLE
#include "VM_mem_check.h"
#include <malloc.h>
#include <stdlib.h>
#include <stdio.h>
extern char _end;
extern "C" char *sbrk(int i);
char *ramstart = (char *)0x20070000;
char *ramend = (char *)0x20088000;
int _VM_freeMemory()
{
	char *heapend = sbrk(0);
	register char * stack_ptr asm("sp");
	struct mallinfo mi = mallinfo();
	//printf("\nDynamic ram used: %d\n", mi.uordblks);
	//printf("Program static ram used %d\n", &_end - ramstart);
	//printf("Stack ram used %d\n\n", ramend - stack_ptr);
	//printf("My guess at free mem: %d\n", stack_ptr - heapend + mi.fordblks);
	return stack_ptr - heapend + mi.fordblks;
}
#endif

#endif


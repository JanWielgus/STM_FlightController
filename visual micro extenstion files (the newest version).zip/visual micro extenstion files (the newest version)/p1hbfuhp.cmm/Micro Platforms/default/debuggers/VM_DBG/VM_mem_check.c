//Source: http://arduino.cc/playground/Code/AvailableMemory

//#if VM_DEBUG_MEM_CHECK == VM_DEBUG_ENABLE

#if defined(ESP8266)

#elif defined(ARDUINO_ARCH_SAMD)||defined(ARDUINO_ARCH_SAM)||defined(ARDUINO_ARCH_ARC32)


#else

#if (ARDUINO >= 100)
#include <Arduino.h>
#else
#include <WProgram.h>
#endif
#if VM_DEBUG_MEM_CHECK == VM_DEBUG_ENABLE
extern unsigned int __heap_start;
extern void *__brkval;

/*
 * The free list structure as maintained by the
 * avr-libc memory allocation routines.
 */
struct __freelist {
	size_t sz;
	struct __freelist *nx;
};

/* The head of the free list structure */
extern struct __freelist *__flp;

#include "VM_mem_check.h"

/* Calculates the size of the free list */
int _VM_freeListSize() {
	struct __freelist* current;
	int total = 0;

	for (current = __flp; current; current = current->nx) {
		total += 2; /* Add two bytes for the memory block's header  */
		total += (int)current->sz;
	}

	return total;
}

int _VM_freeMemory() {
	int free_memory;

	if ((int)__brkval == 0) {
		free_memory = ((int)&free_memory) - ((int)&__heap_start);
	}
	else {
		free_memory = ((int)&free_memory) - ((int)__brkval);
		free_memory += _VM_freeListSize();
	}
	return free_memory;
}
#endif

#endif
//#endif
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"

/*
* Copyright 2018 Visual Micro
*
* See file LICENSE for further informations on licensing terms.
*
* This program is provided WITHOUT ANY WARRANTY; 
* without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*
*/


#define VM_DEBUG_ENABLE 1
//#define VM_DEBUG_START_PRE_DELAY 2000
#include "VM_DBG.h"

#define VM_DBG_WAIT_FOR_PORT 1

#if (defined(VM_DBG_RT_ANALYTICS))
//#include "_dbg.h"
#include "_dbg_pins.h"
#endif


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_GENERIC_OBJECT)
	
#endif


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NO_SERIAL)
#include "_dbg_fake_transport.h"
#endif



#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_USBAPI )
	//#if !defined(__MSP430_HAS_USCI__) && !defined(__MSP430_HAS_USCI_A0__) && !defined(__MSP430_HAS_USCI_A1__) && !defined(__MSP430_HAS_EUSCI_A0__)
	//	#include <TimerSerial.h>
	//#else
		#include <USBAPI.h>
	//#endif
#endif


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == 	VM_DEBUGGER_TYPE_USBAPI )
#include <USBAPI.h>
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == 	VM_DEBUGGER_TYPE_NET_UDP)

#if ( defined(ESP32) || defined(ARDUINO_ARCH_ESP32) || defined(ESP8266) || defined(ARDUINO_ARCH_ESP8266) )	
#if defined(ESP8266)
#include <ESP8266WiFi.h> 
#else
#include <WiFi.h>
#endif
#include <WiFiUdp.h>
#if defined(__ARDUINO_OTA_)
#include <ArduinoOTA.h>
#endif
#endif

#endif


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NET_CONSOLE)
#include <Bridge.h>
#endif


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
#include <SoftwareSerial.h>
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_COSA)
#include "Cosa/UART.hh"
#include "Cosa/Types.h"
#include "Cosa/Bits.h"
#if defined(USBCON)
#include "Cosa/CDC.hh"
#endif

#include "Cosa/RTT.hh"
extern unsigned long millis() {
	return RTT::millis();
}


#include "Cosa/OutputPin.hh"
extern bool digitalRead(uint32_t ix) {
	return Pin::read((Board::DigitalPin) pgm_read_byte(&digital_pin_map[ix]));
}

#include "Cosa/AnalogPin.hh"
extern bool analogRead(uint32_t ix) {
	return -1; //not implemented
			   //Pin::read((Board::AnalogPin) pgm_read_byte(&analog_pin_map[ix]));
}
//#define TOTAL_ANALOG_PINS       membersof(analog_pin_map)
//#define TOTAL_PINS              membersof(digital_pin_map) //NUM_DIGITAL_PINS 


#endif

#if VM_DEBUG_MEM_CHECK == VM_DEBUG_ENABLE
//#include "VM_mem_check.h"
#endif

void VisualMicroDebug::DBG_YieldAndWait(unsigned long ms)
{
	DBG_YieldAndWait(ms, true);
}
void VisualMicroDebug::DBG_YieldAndWait(unsigned long ms, bool handle_events)
{
	unsigned long ms_start = DBG_Millis();
	unsigned long ms_end = ms_start + ms;
	unsigned long ms_curr = ms_start;

	while (true)
	{
#if ( defined(ESP32) || defined(ARDUINO_ARCH_ESP32) || defined(ESP8266) || defined(ARDUINO_ARCH_ESP8266) )	
		//yield();
#endif

		//delay(1);

		ms_curr = DBG_Millis();

		if (ms_curr<ms_start || ms_curr>ms_end) {
			break;
		}

		if (handle_events)
		{
#if (defined(__ARDUINO_OTA_H) || defined(__ARDUINO_OTA_))
			//#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NET_UDP)
						 //if (!WiFi.isConnected())
			if (WiFi.localIP()[0] != 0)
			{
				ArduinoOTA.handle();
			}
			//#endif
#endif
		}
	}

}




//added for cosa
#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_COSA)
uint32_t VisualMicroDebug::DBG_Millis()
{
	return RTT::millis();
}
#else
unsigned long VisualMicroDebug::DBG_Millis()
{
	return millis();
}
#endif

VisualMicroDebug::VisualMicroDebug() {
	//#if defined( DEFAULT_TO_TINY_DEBUG_SERIAL ) && DEFAULT_TO_TINY_DEBUG_SERIAL
	//		transport = &Serial;
	//#endif
	//ensure x millis between each debug packet
	//wait if we have to
	//try to prevent new users from overloading bandwidth and filling windows buffer
	//can be overriden via preferences
	//defaults to 50ms; needs to allow time for windows to recover if it pauses, so we need to be slower than the extensions and debugger can process + a bit

	BreakStartMillis = 0L;
	BreakPrevMillis = 0L;
	InBreakMsgRepeatMS = 0L;
	InBreakMsgSent = 0L;
}


//cosa needs the output buffer recteating before every print. not sure why.
//unused
void VisualMicroDebug::outPacketBeforePrint()
{

}

void VisualMicroDebug::OnBreakPointBegin(unsigned long iInBreakMsgRepeatMS)
{
	InBreakMsgRepeatMS = iInBreakMsgRepeatMS;
	InBreakMsgSent = 0L;
	BreakPrevMillis = BreakStartMillis;
	BreakStartMillis = DBG_Millis();
}

void VisualMicroDebug::OnBreakPointPrintBegin(uint8_t breakpoint_id)
{
	unsigned long m = DBG_Millis();

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
	transport->print("VMDPE_");
	transport->print(breakpoint_id);
	transport->print(":2:"); //header ver 2: start and last times are millis-val to reduce transmition data size
	transport->print(m);
	transport->print(":");
	//millis less time this point started
	transport->print((m - BreakStartMillis));
	transport->print(":");
	//millis since last bp was hit
	transport->print((BreakStartMillis - BreakPrevMillis));
#else
	VM_DEBUGGER_SOFT_TRANSPORT.print("VMDPE_");
	VM_DEBUGGER_SOFT_TRANSPORT.print(breakpoint_id);
	VM_DEBUGGER_SOFT_TRANSPORT.print(":2:"); //header ver 2: start and last times are millis-val to reduce transmition data size
	VM_DEBUGGER_SOFT_TRANSPORT.print(m);
	VM_DEBUGGER_SOFT_TRANSPORT.print(":");
	//millis less time this point started
	VM_DEBUGGER_SOFT_TRANSPORT.print((m - BreakStartMillis));
	VM_DEBUGGER_SOFT_TRANSPORT.print(":");
	//millis since last bp was hit
	VM_DEBUGGER_SOFT_TRANSPORT.print((BreakStartMillis - BreakPrevMillis));
#endif
}
void VisualMicroDebug::OnBreakPointPrintEnd()
{
#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
	transport->println("_VMDPE");
#else
	VM_DEBUGGER_SOFT_TRANSPORT.println("_VMDPE");
#endif
}

void VisualMicroDebug::OnBreakPointEnd()
{
	//update millis to now. ensure time taken for debug doesn't affect comparison of the time to the next point
	BreakStartMillis = DBG_Millis();
}

bool VisualMicroDebug::outPacketStart()
{
	return outPacketStart(false);
}


bool VisualMicroDebug::outPacketStart(bool noWait)
{

	//		//avoid cosa optimizer
	//#if defined(VM_DEBUGGER_TYPE) && VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_COSA
	//			transport = vm_global_dbg_transport;
	//			reader = vm_global_dbg_reader;
	//#endif
	//
#if ( defined(ESP32) || defined(ARDUINO_ARCH_ESP32) || defined(ESP8266) || defined(ARDUINO_ARCH_ESP8266) )	
	//esp8266 crashes if we don't yield often
	yield();
#endif


#if defined(VM_DEBUG_BANDWIDTH_THROTTLE_MS)
	if (!noWait)
	{

		unsigned long ms_wait;
		ms_wait = (DBG_Millis() - lastPacketMS);
		if (ms_wait < VM_DEBUG_BANDWIDTH_THROTTLE_MS)
		{
			ms_wait = (VM_DEBUG_BANDWIDTH_THROTTLE_MS - ms_wait);
			DBG_YieldAndWait(ms_wait, true); //ota events if not first packet/version
		}

		////1501 - for cosa
		////while  (millis()-lastPacketMS<VM_DEBUG_BANDWIDTH_THROTTLE_MS)
		//while ((DBG_Millis() - lastPacketMS) < VM_DEBUG_BANDWIDTH_THROTTLE_MS)
		//{
			//DBG_YieldAndWait(3)
		//}
	}
	//XXX: this should really be after packet end!
	//1501 for cosa - lastPacketMS=millis();
	lastPacketMS = DBG_Millis();

	//ensure user serial is terminated with \n
	//VM_DEBUGGER_SOFT_TRANSPORT.println();
	   
#endif


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NET_UDP)
	//if (!WiFi.isConnected())
	if (WiFi.localIP()[0] == 0)
	{
		//prevent esp8266 crash
		return false;
	}
	//if (!ready_for_use)
	//{
	//	//pc/debugger needs to call us to provide ip address for debug messages
	//	//udp broadcast to sub net takes down routers so be specific!
	//	if (!VM_DEBUGGER_SOFT_TRANSPORT.available())
	//		return false;

	//read port if we have any data because we need the RemoteIP to be set correctly
	//pc sends on debug connect required message
	if (available() > 0)
	{
		char cmd = read();
		if (cmd == 'h')
		{
			//hello - start debug
			//Serial.println("Remote debug session started");
		}
		else if (cmd == 'q')
		{
			//Serial.println("Remote debug session ended");
			//request to close debug session
			RemoteIP[0] = 0;
			RemoteIP[1] = 0;
			RemoteIP[2] = 0;
			RemoteIP[3] = 0;
		}
		else
		{
			//Serial.print("Remote debug cmd: ");
			//Serial.println(cmd);
			//readPacketNextCharIndex--;
		}

	}

	if (RemoteIP[0] == 0)
	{
		//	Serial.println("Can't debug because the remote ip is not set");
		return false;
	}

	//}
	IPAddress ip = RemoteIP; // WiFi.localIP();
	//ip[3] = 4;

	//Udp.println( port.remoteIP(), port.remotePort());
	//VM_DEBUGGER_SOFT_TRANSPORT.beginPacket(ip, 10112, WiFi.localIP());


	transport->beginPacket(ip, 10112);
#endif


	return true;
}


void VisualMicroDebug::outPacketEnd()
{


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NET_UDP)


	if (WiFi.localIP()[0] == 0)
	{
		//prevent esp8266 crash
		return;
	}

	transport->endPacket();

#else

#if ( defined(ESP32) || defined(ARDUINO_ARCH_ESP32) || defined(ESP8266) || defined(ARDUINO_ARCH_ESP8266) )	
	//esp8266 crashes if we don't yield often
	yield();
#else 
	
#endif

#endif

}

/*
void VisualMicroDebug::missedBreakpoint(uint8_t breakpoint_index)
{
missed_breakpoints[missed_breakpoints_counter]=breakpoint_index;
}
void VisualMicroDebug::missedBreakpointsFlush()
{
uint8_t i;
for(i=0;i<missed_breakpoints_counter;i++)
{
//missed_breakpoints[missed_breakpoints_counter]=breakpoint_index;
VM_DEBUGGER_SOFT_TRANSPORT.print("VMDPM_");
VM_DEBUGGER_SOFT_TRANSPORT.print(i);
VM_DEBUGGER_SOFT_TRANSPORT.println("_VMDPM");
delay(5);
}
}
*/

#if defined(VM_DEBUG_USE_PRINT_F)
void VisualMicroDebug::p(char *fmt, ...) {
	char tmp[128]; // resulting string limited to 128 chars
	va_list args;
	va_start(args, fmt);
	vsnprintf(tmp, 128, fmt, args);
	va_end(args);
	
#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
	transport->print(tmp);
#else
	VM_DEBUGGER_SOFT_TRANSPORT.print(tmp);
#endif
}
#endif

/*
#if defined(VM_DEBUGGER_TYPE) && VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_UART
void VisualMicroDebug::begin(UARTClass *theSerial)
{
transport = theSerial;
while(!*theSerial)
{;}
}

void VisualMicroDebug::begin(UARTClass *theSerial, long baud)
{
//delay(500);

transport = theSerial;
while(!*theSerial)
{;}

//VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
//wait for laonardo port to connect. hack! we know it can only be main serial!
//while(!*theSerial)
//{;}
}
#endif
#if defined(VM_DEBUGGER_TYPE) && VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_USART
void VisualMicroDebug::begin(USARTClass *theSerial)
{
transport = theSerial;
while(!*theSerial)
{;}
}

void VisualMicroDebug::begin(USARTClass *theSerial, long baud)
{
//delay(500);

transport = theSerial;
while(!*theSerial)
{;}

//VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
//wait for laonardo port to connect. hack! we know it can only be main serial!
//while(!*theSerial)
//{;}
}
#endif
*/




#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_Uart)
void VisualMicroDebug::begin(Uart *theSerial)
{
	transport = theSerial;
	int n = 0;
	delay(2000);
	/*
	while(!*theSerial)
	{
	if (n>25)
	break;
	n++;
	delay(200);
	}
	*/

	//added for samd-zero
	//VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
}

void VisualMicroDebug::begin(Uart *theSerial, unsigned long baud)
{
	transport = theSerial;
	int n = 0;
	while (!*theSerial)
	{
		if (n > 25)
			break;
		n++;
		delay(200);
	}

	//added for samd-zero
#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
	transport->begin(baud);
#else
	VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
#endif
}
#endif



#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_GENERIC_OBJECT)
void VisualMicroDebug::begin()
{
	//unused we will use VM_DEBUGGER_SOFT_TRANSPORT for all printing
	//transport = theSerial;
	//VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
}

void VisualMicroDebug::begin(unsigned long baud)
{

	//todo: detect usb type ports that need a delay
	//don't wait for the port unless we add a timeout and disable debug. because we might be discntected
	//todo: see if esp can handle this delay wuith wifi also connecting!
	delay(1000);

	//unused we will use VM_DEBUGGER_SOFT_TRANSPORT for all printing
	//transport = theSerial;

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
	transport->begin(baud);
#else
	VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
#endif
}

//void begin(usb_serial_class *theSerial);
//void begin(usb_serial_class *theSerial, unsigned long baud);
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NO_SERIAL)
void VisualMicroDebug::begin(_dbg_fake_transportClass *theSerial)
{
	transport = theSerial;
}
void VisualMicroDebug::begin(_dbg_fake_transportClass *theSerial, unsigned long baud)
{
	transport = theSerial;
}

//void begin(usb_serial_class *theSerial);
//void begin(usb_serial_class *theSerial, unsigned long baud);
#endif


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_TEENSY)
void VisualMicroDebug::begin(usb_serial_class *theSerial)
{

	transport = theSerial;
	int n = 0;
	while (!*theSerial)
	{
		if (n > 25)
			break;
		n++;
		delay(200);
	}
	//delay(VM_DEBUG_START_PRE_DELAY);
}

void VisualMicroDebug::begin(usb_serial_class *theSerial, unsigned long baud)
{
	//delay(500);

	transport = theSerial;
	int n = 0;
	while (!*theSerial)
	{
		if (n > 25)
			break;
		n++;
		delay(200);
	}
	//delay(VM_DEBUG_START_PRE_DELAY);
	//VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
	//wait for laonardo port to connect. hack! we know it can only be main serial!
	//while(!*theSerial)
	//{;}
}
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_HARDWARESERIAL1)
void VisualMicroDebug::begin(HardwareSerial1 *theSerial)
{
	transport = theSerial;
}

void VisualMicroDebug::begin(HardwareSerial1 *theSerial, unsigned long baud)
{
	transport = theSerial;
}
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_HARDWARESERIAL2)
void VisualMicroDebug::begin(HardwareSerial2 *theSerial)
{
	transport = theSerial;
}

void VisualMicroDebug::begin(HardwareSerial2 *theSerial, unsigned long baud)
{
	transport = theSerial;
}
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_HARDWARESERIAL3)
void VisualMicroDebug::begin(HardwareSerial3 *theSerial)
{
	transport = theSerial;
}

void VisualMicroDebug::begin(HardwareSerial3 *theSerial, unsigned long baud)
{
	transport = theSerial;
}
#endif

//DASHPRO
#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SERIALUSB)
void VisualMicroDebug::begin(SerialCDC *theSerial)
{
	transport = theSerial;

	//wait for leonardo port to connect. hack! we know it can only be main serial!
	//exit wait after 3 seconds assume user has disconnected board from pc but left debug running?
	delay(1000);

	int n = 0;
	while (!*theSerial)
	{
		if (n > 30)
			break;
		n++;
		delay(100);
	}

	//delay(VM_DEBUG_START_PRE_DELAY);
}
void VisualMicroDebug::begin(SerialCDC *theSerial, unsigned long baud)
{
	transport = theSerial;

	//wait for leonardo port to connect. hack! we know it can only be main serial!
	//exit wait after 5 seconds assume user has disconnected board from pc but left debug running?
	int n = 0;
	while (!*theSerial)
	{
		if (n > 25)
			break;
		n++;
		delay(100);
	}
	//delay(VM_DEBUG_START_PRE_DELAY);

	VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
}
#endif

//stm32 / feather /chipKIT usb Serial port not Serial0 or Serial1
#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_USBSERIAL)
void VisualMicroDebug::begin(USBSerial *theSerial)
{
	transport = theSerial;

	//wait for leonardo port to connect. hack! we know it can only be main serial!
	//exit wait after 3 seconds assume user has disconnected board from pc but left debug running?
	delay(1000);

	int n = 0;
	while (!*theSerial)
	{
		if (n > 30)
			break;
		n++;
		delay(100);
	}

	//delay(VM_DEBUG_START_PRE_DELAY);
}
void VisualMicroDebug::begin(USBSerial *theSerial, unsigned long baud)
{
	transport = theSerial;

	//wait for leonardo port to connect. hack! we know it can only be main serial!
	//exit wait after 5 seconds assume user has disconnected board from pc but left debug running?
	int n = 0;
	while (!*theSerial)
	{
		if (n > 25)
			break;
		n++;
		delay(100);
	}
	//delay(VM_DEBUG_START_PRE_DELAY);

	VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
}
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == 	VM_DEBUGGER_TYPE_USBAPI)
void VisualMicroDebug::begin(CDC *theSerial)
{
	delay(2000);
	transport = theSerial;

	//wait for leonardo port to connect. hack! we know it can only be main serial!
	//exit wait after 3 seconds assume user has disconnected board from pc but left debug running?
	delay(1000);

	int n = 0;
	while (!*theSerial)
	{
		if (n > 30)
			break;
		n++;
		delay(100);
	}

	//delay(VM_DEBUG_START_PRE_DELAY);
}
void VisualMicroDebug::begin(CDC *theSerial, unsigned long baud)
{
	transport = theSerial;

	//wait for leonardo port to connect. hack! we know it can only be main serial!
	//exit wait after 5 seconds assume user has disconnected board from pc but left debug running?
	int n = 0;
	while (!*theSerial)
	{
		if (n > 25)
			break;
		n++;
		delay(100);
	}
	//delay(VM_DEBUG_START_PRE_DELAY);

	VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
}
#endif


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_USB)
//Board Type = leonardo
void VisualMicroDebug::begin(Serial_ *theSerial)
{
	delay(2000);
	transport = theSerial;

	//wait for leonardo port to connect. hack! we know it can only be main serial!
	//exit wait after 3 seconds assume user has disconnected board from pc but left debug running?
	delay(1000);

	int n = 0;
	while (!*theSerial)
	{
		if (n > 30)
			break;
		n++;
		delay(100);
	}

	//delay(VM_DEBUG_START_PRE_DELAY);
}
void VisualMicroDebug::begin(Serial_ *theSerial, unsigned long baud)
{
	transport = theSerial;

	//wait for leonardo port to connect. hack! we know it can only be main serial!
	//exit wait after 5 seconds assume user has disconnected board from pc but left debug running?
	int n = 0;
	while (!*theSerial)
	{
		if (n > 25)
			break;
		n++;
		delay(100);
	}
	//delay(VM_DEBUG_START_PRE_DELAY);

	VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
}
#endif


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_MS430_SERIAL_)
void VisualMicroDebug::begin(TimerSerial *theSerial)
{
	delay(2000);
	transport = theSerial;

	//wait for leonardo port to connect. hack! we know it can only be main serial!
	//exit wait after 3 seconds assume user has disconnected board from pc but left debug running?
	delay(1000);

	int n = 0;
	while (!*theSerial)
	{
		if (n > 30)
			break;
		n++;
		delay(100);
	}

	//delay(VM_DEBUG_START_PRE_DELAY);
}
void VisualMicroDebug::begin(TimerSerial *theSerial, unsigned long baud)
{
	transport = theSerial;

	//wait for leonardo port to connect. hack! we know it can only be main serial!
	//exit wait after 5 seconds assume user has disconnected board from pc but left debug running?
	int n = 0;
	while (!*theSerial)
	{
		if (n > 25)
			break;
		n++;
		delay(100);
	}
	//delay(VM_DEBUG_START_PRE_DELAY);

	VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
}
//#else
////Board Type = leonardo
//void VisualMicroDebug::begin(Serial_ *theSerial)
//{
//	delay(2000);
//	transport = theSerial;
//
//	//wait for leonardo port to connect. hack! we know it can only be main serial!
//	//exit wait after 3 seconds assume user has disconnected board from pc but left debug running?
//	delay(1000);
//
//	int n = 0;
//	while (!*theSerial)
//	{
//		if (n > 30)
//			break;
//		n++;
//		delay(100);
//	}
//
//	//delay(VM_DEBUG_START_PRE_DELAY);
//}
//
//void VisualMicroDebug::begin(Serial_ *theSerial, unsigned long baud)
//{
//	transport = theSerial;
//
//	//wait for leonardo port to connect. hack! we know it can only be main serial!
//	//exit wait after 5 seconds assume user has disconnected board from pc but left debug running?
//	int n = 0;
//	while (!*theSerial)
//	{
//		if (n > 25)
//			break;
//		n++;
//		delay(100);
//	}
//	//delay(VM_DEBUG_START_PRE_DELAY);
//
//	VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
//}
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NET_UDP)
void VisualMicroDebug::begin(WiFiUDP *theSerial, unsigned long port)
{
	reader = &VM_DEBUG_UDP_READER;
	reader->begin(10113);

	transport = theSerial;
	//reader->theSerial;

	//VM_DEBUGGER_SOFT_TRANSPORT.begin(10112);

	//192.168.2.6
}
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NET_CONSOLE)

void VisualMicroDebug::begin(ConsoleClass *theSerial, unsigned long baud)
{
	transport = theSerial;
	//hack
	//console crashes if bridge not started
	Bridge.begin();
	Console.begin();
	delay(2000);

	//VM_DEBUGGER_SOFT_TRANSPORT.begin();
	//delay(VM_DEBUG_START_PRE_DELAY);
}
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_TTYUART)

void VisualMicroDebug::begin(TTYUARTClass *theSerial, unsigned long baud)
{
	transport = theSerial;
	VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
	//delay(VM_DEBUG_START_PRE_DELAY);
}
#endif


//#if defined(VM_DEBUGGER_TYPE) && VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_USBSERIAL
//
//	void VisualMicroDebug::begin(USBSerial *theSerial, unsigned long baud)
//	{
//		transport = theSerial;
//		VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
//		//delay(VM_DEBUG_START_PRE_DELAY);
//	}
//#endif

#if (defined(VM_DBG_RT_ANALYTICS))
_dbg_pins  VisualMicroDebug::pins() {
	return vmdebug.stats();
}
#endif


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_COSA)
void VisualMicroDebug::init(unsigned long delayMs)
{
	lastPacketMS = 0L;
	baudRate = 0L; //gets a value later if required, only used by cosa for a re-begin!

	RTT::begin();

	if (delayMs > 0)
		delay(delayMs);
}

#if defined(USBCON)
void VisualMicroDebug::begin(CDC *theSerial, unsigned long int baud)
{
	baudRate = baud;
	
	// Create an instance of the iostream and bind to the uart
	static IOStream dbgSerial(theSerial);
	transport = &dbgSerial;

	reader = theSerial;
	reader->begin(baud);


}
#else
void VisualMicroDebug::begin(UART *theSerial, unsigned long int baud)
{
	baudRate = baud;

	// Create an instance of the iostream and bind to the uart
	static IOStream dbgSerial(theSerial);
	transport = &dbgSerial;

	reader = theSerial;
	reader->begin(baud);


}
#endif
#else
void VisualMicroDebug::init(unsigned long delayMs)
{
//
#if (defined(VM_DBG_RT_ANALYTICS))
	//ensure we are not optimized out as an object
	//todo: ensure pins code is highly optimized so the debugger doesn't try to step into it?
	vmdebug.init();
	vmdebug.stats();
#endif


	baudRate = 0L; //gets a value later if required, only used by cosa for a re-begin!

	lastPacketMS = 0L;

	//note: a delay at start causes esp8266 wifi to fail to connect!!
	//		the delay can also be switched off via board/platform.txt property=
	if (delayMs > 0)
		DBG_YieldAndWait(delayMs);

}
#endif




#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_CDCSerialClass)
void VisualMicroDebug::begin(CDCSerialClass *theSerial, unsigned long baud)
{
	transport = theSerial;


	//wait for leonardo port to connect. hack! we know it can only be main serial!
	//exit wait after 5 seconds assume user has disconnected board from pc but left debug running?
	int n = 0;
	while (!*theSerial)
	{
		if (n > 25)
			break;
		n++;
		delay(150);
	}
	VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
	//delay(VM_DEBUG_START_PRE_DELAY);
}
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_UART)

void VisualMicroDebug::begin(UARTClass *theSerial, unsigned long baud)
{
	transport = theSerial;
	VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
	//delay(VM_DEBUG_START_PRE_DELAY);
}
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_USART)

void VisualMicroDebug::begin(USARTClass *theSerial, unsigned long baud)
{
	transport = theSerial;
	VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);
	//delay(VM_DEBUG_START_PRE_DELAY);
}
#endif


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_HARDWARESERIAL)
#if defined( DEFAULT_TO_TINY_DEBUG_SERIAL ) && DEFAULT_TO_TINY_DEBUG_SERIAL
void VisualMicroDebug::begin(TinyDebugSerial *theSerial)
{
	transport = theSerial;
}

void VisualMicroDebug::begin(TinyDebugSerial *theSerial, long baud)
{
	transport = theSerial;
	if (baud == 115200)
		VM_DEBUGGER_SOFT_TRANSPORT.begin(115200L);
	else if (baud == 38400)
		VM_DEBUGGER_SOFT_TRANSPORT.begin(38400L);
	else if (baud == 9600)
		VM_DEBUGGER_SOFT_TRANSPORT.begin(9600L);
	else VM_DEBUGGER_SOFT_TRANSPORT.begin(115200L);


}


#else

void VisualMicroDebug::begin(HardwareSerial *theSerial)
{
	transport = theSerial;
}
void VisualMicroDebug::begin(HardwareSerial *theSerial, unsigned long baud)
{
	transport = theSerial;
	VM_DEBUGGER_SOFT_TRANSPORT.begin(baud);

	//delay(VM_DEBUG_START_PRE_DELAY);
}

#endif
#endif


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
void VisualMicroDebug::begin(SoftwareSerial *theSerial)
{
	transport = theSerial;
	transport->listen();
	//delay(VM_DEBUG_START_PRE_DELAY); //try to stop initial rubbish in debug console
	//#if VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL

	//#endif
}
void VisualMicroDebug::begin(SoftwareSerial *theSerial, unsigned long baud)
{
	transport = theSerial;
	transport->begin(baud);
	transport->listen();
	//delay(VM_DEBUG_START_PRE_DELAY); //try to stop initial rubbish in debug console
}
#endif


void VisualMicroDebug::start(bool waitForKeyToStart, bool _alwaysBreak)
{
#if defined (VM_DEBUG_BREAKPAUSE)
	if (waitForKeyToStart)
	{
		alwaysBreak = true;

		//server should know we are waiting sendMessage("Press any key to continue");
		while (breakWait(0) != 'c') {
			DBG_YieldAndWait(1);
		}
		//breakWait(0);
	}
	alwaysBreak = _alwaysBreak;
#endif

}

unsigned char VisualMicroDebug::read()
{
	unsigned char b;

#if (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NET_UDP)

	if (readPacketNextCharIndex >= readPacketSize)
	{
		readPacketSize = reader->parsePacket();
		if (readPacketSize <= 0)
		{
			//error
		}
		int len = reader->read(readPacketBuffer, 254);
		if (len > 0) readPacketBuffer[len] = 0;
		readPacketSize = len;
		readPacketNextCharIndex = 0;

		//save the last known attached debug pc ip so we know where to send debug messages
		RemoteIP = reader->remoteIP();

		//esp only receives one packet, so ensure port listener is reset
		reader->begin(10113);

		// send a reply, to the IP address and port that sent us the packet we received
		//reader->beginPacket(reader->remoteIP(), reader->remotePort());
		//reader->print("VMIPR_");
		//reader->print(readPacketSize);
		//reader->println("_VMIPR");
		//reader->endPacket();
	}

	b = readPacketBuffer[readPacketNextCharIndex];
	readPacketNextCharIndex++;

	//	// Serial.println(packetSize);
	//	if (packetSize) {
	//		int len = port.read(packetBuffer, 255);
	//		if (len > 0) packetBuffer[len - 1] = 0;

#elif defined(VMDGB_HAS_READER)
	b = reader->getchar();
#elif defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
	b = transport->read();
#else
	b = VM_DEBUGGER_SOFT_TRANSPORT.read();
#endif
	return b;
}

unsigned char VisualMicroDebug::peek()
{
	unsigned char b;
#if (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NET_UDP)
	b = read();
	if (readPacketNextCharIndex > 0) 	readPacketNextCharIndex--;

#elif defined(VMDGB_HAS_READER)
	b = reader->peekchar();
#elif defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
	b = transport->peek();
#else
	b = VM_DEBUGGER_SOFT_TRANSPORT.peek();
#endif
	return b;
}

uint8_t VisualMicroDebug::available()
{
	uint8_t b;

#if (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NET_UDP)
	b = reader->available();
	b += (readPacketSize - readPacketNextCharIndex);
#elif defined(VMDGB_HAS_READER)
	b = reader->available();
#elif defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
	b = transport->available();
#else
	b = VM_DEBUGGER_SOFT_TRANSPORT.available();
#endif
	return b;
}


/*
*
*
*/
#if defined (VM_DEBUG_BREAKPAUSE)

#if defined(VM_DEBUGGER_TYPE) //&& ( VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_HARDWARESERIAL || VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_FASTSERIAL)
//TODO: implement sturcture serial com!
//we never get called if break was not set during compliation
//return _vm_cmd so that we can setVariable if required (caller needs to know result)
uint8_t VisualMicroDebug::breakWait(uint8_t breakPointId)
{

	//console write not working yet
#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NET_CONSOLE)
	return 'c';
#endif

	if (!alwaysBreak)
	{
		//if dedicated debug port then we can perform a quick check on serial
		//for vm command to switch back on breaks
		return 'c';
	}


	uint8_t b;

	//break/pause until we get a command
	while (available() == 0)
	{


#if (defined(__ARDUINO_OTA_H) || defined(__ARDUINO_OTA_))
		//Serial.print("Waiting at breakpoint: ");
		//Serial.println(breakPointId);
			//ArduinoOTA.handle();
		DBG_YieldAndWait(5, true); //ota
#endif

		return 'e';
		//delay(10);
		//detect incoming byte as quickly as possible
	}


	//#if defined(VMDGB_HAS_READER)
	//	while(reader->available()==0)
	//		{
	//			//delay(10);
	//			//detect incoming byte as quickly as possible
	//		}
	//
	//#else
	//	while(VM_DEBUGGER_SOFT_TRANSPORT.available()==0)
	//		{
	//			//delay(10);
	//			//detect incoming byte as quickly as possible
	//		}
	//
	//#endif

	//delay(10); //wait for rest

	//note: work in progress!!
	//todo: implement decent command header	instead of this. 
	//		cows have 7 stomachs and chickens have 12 eggs inside them most of the time
	//doh!  better if we have any key to continue so users data doesn't get lost so much. 
	//NOTE. pause/breakpoints are best used with dedicated port!
	//while(true)
	//{

	while (available() > 0)
	{

		b = read();
		//VM_DEBUGGER_SOFT_TRANSPORT.print("Received: ");
		//VM_DEBUGGER_SOFT_TRANSPORT.println(b);

		//#if defined(VMDGB_HAS_READER)
		//		while(reader->available()>0)
		//		{
		//			//cossa
		//			b = reader->getchar();
		//#else
		//		while(VM_DEBUGGER_SOFT_TRANSPORT.available()>0)
		//		{
		//			b = VM_DEBUGGER_SOFT_TRANSPORT.read();
		//#endif
		//debug break commands
		switch (b)
		{

		case 'c':
			sendContinuedACK(breakPointId);
			return 'c'; //if we get here we are continuing!


		case 'v': //setVariableValue
			return b; //caller will come back again after setting variable value
					  //break;

					  //continue
					  //case 'c':
					  //	sendContinuedACK(breakPointId);
					  //	return;

					  //switch off break until re-start. for dev/testing
		case 'X':
			alwaysBreak = false;
			return 'c';
			break;


		case 'h':
			//Serial.println("Remote debug session started");
			return 'c';
			break;

		case 'q':
			//Serial.println("Remote debug session ended");
#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NET_UDP)
			//request to close debug session
			RemoteIP[0] = 0;
			RemoteIP[1] = 0;
			RemoteIP[2] = 0;
			RemoteIP[3] = 0;
#endif
			return 'c';
			break;

		}
	}
	//}
	//while(printer->available()>0)
	//printer->read();
	//sendContinuedACK(breakPointId);
	//return 'c'; //if we get here we are continuing!

	//	return '?'; //software serial rubbish detected?

	return 'e';
}
#endif


/*
#if defined(VM_DEBUGGER_TYPE) && VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL

//TODO: implement sturcture serial com!
//we never get called if break was not set during compliation
void VisualMicroDebug::breakWait(uint8_t breakPointId)
{
if (!alwaysBreak)
{
//if dedicated debug port then we can perform a quick check on serial
//for vm command to switch back on breaks
return;
}
VM_DEBUGGER_SOFT_TRANSPORT.listen();

while(!VM_DEBUGGER_SOFT_TRANSPORT.available())
{
//delay(10);
//detect incoming byte as quickly as possible
}

//delay(10); //wait for rest
byte b;

//note: work in progress!!
//todo: implement decent command header	instead of this.
//		cows have 7 stomachs and chickens have 12 eggs inside them most of the time
//doh!  better if we have any key to continue so users data doesn't get lost so much.
//NOTE. pause/breakpoints are best used with dedicated port!
//while(true)
//{
//while(printer->available()>0)
//{
b = VM_DEBUGGER_SOFT_TRANSPORT.read();
//debug break commands
switch (b)
{
//continue
//case 'c':
//	sendContinuedACK(breakPointId);
//	return;

//switch off break until re-start. for dev/testing
case 'X':
alwaysBreak=false;
break;
}
//}
//}
//while(printer->available()>0)
//printer->read();
sendContinuedACK(breakPointId);
}
#endif
*/


void VisualMicroDebug::sendContinuedACK(uint8_t breakPointId)
{
	outPacketStart(true);

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
	transport->print("VMDPC_");
	//todo: arduino early versions prior to 1.0 will not convert this number in the same way
	transport->print(breakPointId);

	//1501 - split into two because cosa doesn't support println(str)
	transport->println("_VMDPC");
#else
	VM_DEBUGGER_SOFT_TRANSPORT.print("VMDPC_");
	//todo: arduino early versions prior to 1.0 will not convert this number in the same way
	VM_DEBUGGER_SOFT_TRANSPORT.print(breakPointId);

	//1501 - split into two because cosa doesn't support println(str)
	VM_DEBUGGER_SOFT_TRANSPORT.println("_VMDPC");

	//VM_DEBUGGER_SOFT_TRANSPORT.println("bp ok sent");
	//VM_DEBUGGER_SOFT_TRANSPORT.println();

#endif

	outPacketEnd();

	//#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NET_UDP)
	//	reader->flush();
	//	VM_DEBUGGER_SOFT_TRANSPORT.flush();
	//#endif

		//nb: 2560 looses some chars of 2nd and third print statements after startup. todo: look into this!
		//the following delay seems to sort it out sometimes!
	DBG_YieldAndWait(50);
}

#endif //_VM_DEBUG_BREAKPAUSE



void VisualMicroDebug::sendMessage(const char debugger_message[])
{
	//1501 - split this into two calls because cosa doesn;t support println(str)
#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
	transport->print(debugger_message);
	transport->println();
#else
	VM_DEBUGGER_SOFT_TRANSPORT.print(debugger_message);
	VM_DEBUGGER_SOFT_TRANSPORT.println();
#endif
}


#if defined(VM_DEBUG_AUTO_REPORTING)

#define TOTAL_DIGITAL_PINS TOTAL_PINS-TOTAL_ANALOG_PINS

//reporting
#if VM_DEBUG_READ_DIGITAL_PORTS == VM_DEBUG_ENABLE 

void VisualMicroDebug::printPortsDigital()
{
	uint32_t i;
	unsigned char pByte = 0;
	unsigned char bitCounter = 0;
	uint32_t v = 0;
	bool state;
	for (i = 0; i < TOTAL_DIGITAL_PINS; i++)
	{
		state = false;
		//don't bother with hardware serial
		if (i > 1)
		{
			v = digitalRead(i);
			if (v > 0)
				state = true;
			else state = false;
		}

		pByte |= (state << bitCounter);

		bitCounter++;
		//NEXT BYTE
		if (bitCounter == 8 || i == TOTAL_DIGITAL_PINS - 1)
		{
			//VM_DEBUGGER_SOFT_TRANSPORT.print("D");
#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
			transport->print(pByte);
			transport->print(":");
#else
			VM_DEBUGGER_SOFT_TRANSPORT.print(pByte);
			VM_DEBUGGER_SOFT_TRANSPORT.print(":");
#endif
			bitCounter = 0;
			pByte = 0;
		}


		DBG_YieldAndWait(1);

	}
}
#endif

//uint8_t VM_DBG_LAST_PORT_VALUES[TOTAL_PORTS];
//uint8_t VM_DBG_TEMP_UNINT8_T=0;
/*
void VisualMicroDebug::printPortsDigital()
{

byte i;
for (i=0; i<TOTAL_PORTS; i++)
{

#if defined(_VM_DEBUG_USE_PRINT_F)
p("%*d=%*d:",i,readPort(i,255));
#else
VM_DEBUGGER_SOFT_TRANSPORT.print(i);
VM_DEBUGGER_SOFT_TRANSPORT.print("=");
VM_DEBUGGER_SOFT_TRANSPORT.print(readPort(i,255));
VM_DEBUGGER_SOFT_TRANSPORT.print(":");
#endif

}

}

*/
/*

void VisualMicroDebug::printPortsDigital()
{
tmp_found = false;

byte i;
for (i=0; i<TOTAL_PORTS; i++)
{
VM_DBG_TEMP_UNINT8_T = readPort(i,255);
if (VM_DBG_LAST_PORT_VALUES[i]!=VM_DBG_TEMP_UNINT8_T)
{
if (!tmp_found)
{
tmp_found=true;
//MicroDebug.VM_DEBUGGER_SOFT_TRANSPORT.print("PORTS");
}

VM_DBG_LAST_PORT_VALUES[i] = VM_DBG_TEMP_UNINT8_T;

#if defined(_VM_DEBUG_USE_PRINT_F)
p("%*d:%*d",i,VM_DBG_TEMP_UNINT8_T);
#else
VM_DEBUGGER_SOFT_TRANSPORT.print(":");
VM_DEBUGGER_SOFT_TRANSPORT.print(i);
VM_DEBUGGER_SOFT_TRANSPORT.print("=");
VM_DEBUGGER_SOFT_TRANSPORT.print(VM_DBG_TEMP_UNINT8_T);
#endif
}
}

//if (tmp_found)
//MicroDebug.VM_DEBUGGER_SOFT_TRANSPORT.println("PORTS");
}

*/



#if (VM_DEBUG_MEM_CHECK == VM_DEBUG_ENABLE)
void VisualMicroDebug::printFreeMemory()
{
#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
	transport->print(_VM_freeMemory());
#else
	VM_DEBUGGER_SOFT_TRANSPORT.print(_VM_freeMemory());
#endif
}
/*unsigned long VisualMicroDebug::getFreeMemory()
{
return _VM_freeMemory();
}*/

#endif



#if (VM_DEBUG_READ_ANALOG_PINS == VM_DEBUG_ENABLE)
void VisualMicroDebug::printPinsAnalog()
{

	int analogPin = 0; // counter for reading analog pins
	int analogData; // storage variable for data from analogRead()

	for (analogPin = 0; analogPin < TOTAL_ANALOG_PINS; analogPin++)
	{
		//if( analogPinsToReport & (1 << analogPin) ) {
		//delay(4);
		analogData = analogRead(analogPin);
		//VM_DEBUGGER_SOFT_TRANSPORT.print(analogPin);
		// These two bytes converted back into the 10-bit value on host
		//VM_DEBUGGER_SOFT_TRANSPORT.print("=");
#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
		transport->print(analogData);
		transport->print(":");
#else

		VM_DEBUGGER_SOFT_TRANSPORT.print(analogData);
		//VM_DEBUGGER_SOFT_TRANSPORT.print(analogData % 128);
		//VM_DEBUGGER_SOFT_TRANSPORT.print(analogData >> 7); 
		VM_DEBUGGER_SOFT_TRANSPORT.print(":");
#endif
	}
	//VM_DEBUGGER_SOFT_TRANSPORT.println(":ANALOGS");
}
#endif



#if defined(VM_DEBUG_I2C)
#include <Wire.h>

extern "C" {
#include <utility/twi.h>  // from Wire library, so we can do bus scanning
}

void VisualMicroDebug::initI2C()
{
	Wire.begin();
}

#if (VM_DEBUG_READ_I2C_DEVICES == VM_DEBUG_ENABLE)

void VisualMicroDebug::printI2CDeviceList()
{
	if (devicesFound)
		return;

	//tmp_found=false;
	uint8_t from_addr = 8;
	uint8_t to_addr = 118; //#119 seems erratic
	uint8_t rc;
	uint8_t data = 0; // not used, just an address to feed to twi_writeTo()
	for (byte addr = from_addr; addr <= to_addr; addr++)
	{
		rc = twi_writeTo(addr, &data, 0, 1, 1);
		if (rc == 0)
		{
			//		if (!tmp_found)
			//		{
			//			tmp_found=true;
			//			VM_DEBUGGER_SOFT_TRANSPORT.print("VMDPI_");
			//		}	

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
			transport->print(addr);
			transport->print(":");
#else
			VM_DEBUGGER_SOFT_TRANSPORT.print(addr);
			VM_DEBUGGER_SOFT_TRANSPORT.print(":");
#endif
			devicesFound = true;
		}

	}

	//if (tmp_found)
	//	VM_DEBUGGER_SOFT_TRANSPORT.println("_VMDPI");

}

#endif //i2c scan
#endif //i2c
#endif

/*
#if defined(VM_DEBUG_WRITEVARS_SIMPLE)

void VisualMicroDebug::setVariable(long &i, int j)
{
delay(5); //make sure we get the whole data packet. needs a check sum or something!
uint8_t dtype = readVariableTextDataType();
uint8_t len = readVariableTextLength();

char readString[17];

for(uint16_t r=0; r<len; r++) {
readString[r]=VM_DEBUGGER_SOFT_TRANSPORT.read();
}
readString[len] = '\0';

i = atol(readString);

#if defined(VM_DEBUG_WRITEVAR_CONFIRM)
VM_DEBUGGER_SOFT_TRANSPORT.print("l_Variable value received: Len=");
VM_DEBUGGER_SOFT_TRANSPORT.print(len);
VM_DEBUGGER_SOFT_TRANSPORT.print(" text data type=");
VM_DEBUGGER_SOFT_TRANSPORT.print(dtype);
VM_DEBUGGER_SOFT_TRANSPORT.print(" value=");
VM_DEBUGGER_SOFT_TRANSPORT.println(i);
#endif
}

void VisualMicroDebug::setVariable(unsigned long &i, int j)
{
delay(5); //make sure we get the whole data packet. needs a check sum or something!
uint8_t dtype = readVariableTextDataType();
uint8_t len = readVariableTextLength();

char readString[17];

for(uint16_t r=0; r<len; r++) {
readString[r]=VM_DEBUGGER_SOFT_TRANSPORT.read();
}
readString[len] = '\0';

i = atol(readString);


VM_DEBUGGER_SOFT_TRANSPORT.print("l_Variable value received: Len=");
VM_DEBUGGER_SOFT_TRANSPORT.print(len);
VM_DEBUGGER_SOFT_TRANSPORT.print(" text data type=");
VM_DEBUGGER_SOFT_TRANSPORT.print(dtype);
VM_DEBUGGER_SOFT_TRANSPORT.print(" value=");
VM_DEBUGGER_SOFT_TRANSPORT.println(i);

}

void VisualMicroDebug::setVariable(float &i, int j) {
delay(5); //make sure we get the whole data packet. needs a check sum or something!
uint8_t dtype = readVariableTextDataType();
uint8_t len = readVariableTextLength();

char readString[20];
for(uint16_t r=0; r<len; r++) {
readString[r]=VM_DEBUGGER_SOFT_TRANSPORT.read();
}
readString[len] = '\0';
i = atof(readString);

VM_DEBUGGER_SOFT_TRANSPORT.print("f_Variable value received: Len=");
VM_DEBUGGER_SOFT_TRANSPORT.print(len);
VM_DEBUGGER_SOFT_TRANSPORT.print(" text data type=");
VM_DEBUGGER_SOFT_TRANSPORT.print(dtype);
VM_DEBUGGER_SOFT_TRANSPORT.print(" value=");
VM_DEBUGGER_SOFT_TRANSPORT.println(i);

}


void VisualMicroDebug::setVariable( unsigned int &i, int j )
{
delay(5); //make sure we get the whole data packet. needs a check sum or something!
uint8_t dtype = readVariableTextDataType();
uint8_t len = readVariableTextLength();

char readString[5];
for(uint16_t r=0; r<len; r++) {
readString[r]=VM_DEBUGGER_SOFT_TRANSPORT.read();
}
readString[len] = '\0';
i = atoi(readString);


VM_DEBUGGER_SOFT_TRANSPORT.print("Variable value received: Len=");
VM_DEBUGGER_SOFT_TRANSPORT.print(len);
VM_DEBUGGER_SOFT_TRANSPORT.print(" text data type=");
VM_DEBUGGER_SOFT_TRANSPORT.print(dtype);
VM_DEBUGGER_SOFT_TRANSPORT.print(" value=");
VM_DEBUGGER_SOFT_TRANSPORT.println(i);

}
void VisualMicroDebug::setVariable( int &i, int j )
{
delay(5); //make sure we get the whole data packet. needs a check sum or something!
uint8_t dtype = readVariableTextDataType();
uint8_t len = readVariableTextLength();

char readString[5];
for(uint16_t r=0; r<len; r++) {
readString[r]=VM_DEBUGGER_SOFT_TRANSPORT.read();
}
readString[len] = '\0';
i = atoi(readString);

VM_DEBUGGER_SOFT_TRANSPORT.print("Variable value received: Len=");
VM_DEBUGGER_SOFT_TRANSPORT.print(len);
VM_DEBUGGER_SOFT_TRANSPORT.print(" text data type=");
VM_DEBUGGER_SOFT_TRANSPORT.print(dtype);
VM_DEBUGGER_SOFT_TRANSPORT.print(" value=");
VM_DEBUGGER_SOFT_TRANSPORT.println(i);
}
#endif
*/


#if defined(VM_DEBUG_WRITEVARS_SIMPLE) || defined(VM_DEBUG_WRITEVARS_ADVANCED)

//#if defined(VMDGB_HAS_READER)
//	uint8_t VisualMicroDebug::readVariableTextDataType() 
//	{
//		return reader->getchar();
//	}
//	
//	uint8_t VisualMicroDebug::readVariableTextLength() 
//	{
//		return reader->getchar();
//	}
//#else
uint8_t VisualMicroDebug::readVariableTextDataType()
{
	return read();
	//return VM_DEBUGGER_SOFT_TRANSPORT.read();
}

uint8_t VisualMicroDebug::readVariableTextLength()
{
	return read();
	//return VM_DEBUGGER_SOFT_TRANSPORT.read();
}
//#endif

#endif


#if defined(VM_DEBUG_WRITEVARS_ADVANCED)


void no_lvalue_err()
{
#if defined(VM_DEBUG_WRITEVAR_CONFIRM)
#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
	MicroDebug.transport->print("Error: Attempt to set a read-only variable or data type not supported\r\n");
#else
	VM_DEBUGGER_SOFT_TRANSPORT.print("Error: Attempt to set a read-only variable or data type not supported\r\n");
#endif
#endif

	// you can put any code here that will be executed if the user tries to set a variable that isn't any (that is no lvalue)
}


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_COSA)
#define VM_DEBUG_DEC 10
#define VM_DEBUG_BIN 2
#define VM_DEBUG_OCT 8
#define VM_DEBUG_HEX 16
#else
#define VM_DEBUG_DEC DEC
#define VM_DEBUG_BIN BIN
#define VM_DEBUG_OCT OCT
#define VM_DEBUG_HEX HEX
#endif

long VisualMicroDebug::vmstrtol(char *rs, byte format)
{
	byte base = VM_DEBUG_DEC;

#if VM_DEBUG_DEC == 10 && VM_DEBUG_HEX == 16 && VM_DEBUG_OCT == 8 && VM_DEBUG_BIN == 2
	if (format != 0)
		base = format;	// that's how it is currently defined in print.h
#else
	switch (format)
	{
	case VM_DEBUG_HEX:	base = 16; break;
	case VM_DEBUG_OCT:	base = 8; break;
	case VM_DEBUG_BIN:	base = 2; break;
	}
#endif

	return strtol(rs, NULL, base);
}

unsigned long VisualMicroDebug::vmstroul(char *rs, byte format)
{
	byte base = VM_DEBUG_DEC;

#if VM_DEBUG_DEC == 10 && VM_DEBUG_HEX == 16 && VM_DEBUG_OCT == 8 && VM_DEBUG_BIN == 2
	if (format != 0)
		base = format;	// that's how it is currently defined in print.h
#else
	switch (format)
	{
	case VM_DEBUG_HEX:	base = 16; break;
	case VM_DEBUG_OCT:	base = 8; break;
	case VM_DEBUG_BIN:	base = 2; break;
	}
#endif

	return strtoul(rs, NULL, base);
}

#endif



/* cosa is lacking the following functions, that's why we #define them here
* 2015.07.19 HK
*/
#if ( defined(VM_DEBUGGER_TYPE) && VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_COSA) || defined(VM_DEBUG_NEED_STR_CONV_METHODS)
#define isspace(c) (c == ' ')
#define isascii(c) (c < '\x7f')
#define isdigit(c) (c >= '0' && c <= '9')
#define isalpha(c) ((c >='a' && c <='z') || (c >='A' && c <='Z'))
#define isupper(c) (c >='A' && c <='Z')
#endif

/*
* For the following strtoul function only:
*
* Copyright (c) 1990, 1993
*      The Regents of the University of California.  All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
* 1. Redistributions of source code must retain the above copyright
*        notice, this list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright
*        notice, this list of conditions and the following disclaimer in the
*        documentation and/or other materials provided with the distribution.
* 3. Neither the name of the University nor the names of its contributors
*        may be used to endorse or promote products derived from this software
*        without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED.      IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
* OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
* OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
* SUCH DAMAGE.
*/

/* strtoul for toolchains that are lacking this function (e.g. ESP8266
* 2015.05.16 HK
*/

#ifndef ULONG_MAX
#define ULONG_MAX 0xFFFFFFFFUL
#endif

#ifndef ARDUINO_ARCH_ARC32

extern "C" unsigned long __attribute__((weak)) strtoul(const char *nptr, char **endptr, int base)
{
	const char     *s = nptr;
	unsigned long   acc;
	unsigned char   c;
	unsigned long   cutoff;
	int             neg = 0, any, cutlim;

	/*
	* See strtol for comments as to the logic used.
	*/
	do {
		c = *s++;
	} while (isspace(c));
	if (c == '-') {
		neg = 1;
		c = *s++;
	}
	else if (c == '+')
		c = *s++;
	if ((base == 0 || base == 16) && c == '0' && (*s == 'x' || *s == 'X')) {
		c = s[1];
		s += 2;
		base = 16;
	}
	if (base == 0)
		base = c == '0' ? 8 : 10;
	cutoff = (unsigned long)ULONG_MAX / (unsigned long)base;
	cutlim = (unsigned long)ULONG_MAX % (unsigned long)base;
	for (acc = 0, any = 0;; c = *s++) {
		if (!isascii(c))
			break;
		if (isdigit(c))
			c -= '0';
		else if (isalpha(c))
			c -= isupper(c) ? 'A' - 10 : 'a' - 10;
		else
			break;
		if (c >= base)
			break;
		if (any < 0 || acc > cutoff || (acc == cutoff && c > cutlim))
			any = -1;
		else {
			any = 1;
			acc *= base;
			acc += c;
		}
	}
	if (any < 0) {
		acc = ULONG_MAX;
		// errno = ERANGE; note: removed for use with *duinos
	}
	else if (neg)
		acc = -acc;
	if (endptr != 0)
		*endptr = (char *)(any ? s - 1 : nptr);
	return (acc);
}

#endif // !ARDUINO_ARCH_ARC32

//void VisualMicroDebug::fetchVarData( char *buf )
//#if defined(VM_DEBUGGER_TYPE) && VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_COSA
//void VisualMicroDebug::fetchVarData()
//{
//	//dummy not impemented
//}
//#else
void VisualMicroDebug::fetchVarData()
{
	//#if defined(VM_DEBUG_WRITEVAR_CONFIRM)
	//	VM_DEBUGGER_SOFT_TRANSPORT.println("Variable Value: ");
	//#endif

	DBG_YieldAndWait(10);

	//delay(10); //make sure we get the whole data packet. needs a check sum or something!

			   //uint8_t dtype = 
	readVariableTextDataType();

	uint8_t len = readVariableTextLength();

	//#if defined(VM_DEBUG_WRITEVAR_CONFIRM)
	//	VM_DEBUGGER_SOFT_TRANSPORT.print(len);
	//#endif

	for (byte r = 0; r < len; r++) {
		readString[r] = read();
		//buf[r]=VM_DEBUGGER_SOFT_TRANSPORT.read();
		//#if (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_COSA)
		//		readString[r] = reader->getchar();
		//		//MicroDebug.
		//#else
		//		readString[r]=VM_DEBUGGER_SOFT_TRANSPORT.read();
		//		MicroDebug.
		//#endif
	}
	//buf[len] = '\0';
	readString[len] = '\0';

	//#if defined(VM_DEBUG_WRITEVAR_CONFIRM)
	//	VM_DEBUGGER_SOFT_TRANSPORT.print("Variable Value: ");
	//	VM_DEBUGGER_SOFT_TRANSPORT.print(len);
	//	VM_DEBUGGER_SOFT_TRANSPORT.print(" text data type=");
	//	VM_DEBUGGER_SOFT_TRANSPORT.print(dtype);
	//#endif
}
//#endif

void VisualMicroDebug::vmsetvar(char *rs, byte format, char *v) { strcpy(v, rs); }
void VisualMicroDebug::vmsetvar(char *rs, byte format, int16_t &v) { v = (int16_t)vmstrtol(rs, format); }
void VisualMicroDebug::vmsetvar(char *rs, byte format, uint16_t &v) { v = (uint16_t)vmstroul(rs, format); };
#if __SIZEOF_INT__ == __SIZEOF_LONG__
// for 32 Bit CPUs
void VisualMicroDebug::vmsetvar(char *rs, byte format, int &v) { v = vmstrtol(rs, format); };
void VisualMicroDebug::vmsetvar(char *rs, byte format, unsigned int &v) { v = vmstroul(rs, format); };
#endif
void VisualMicroDebug::vmsetvar(char *rs, byte format, long &v) { v = vmstrtol(rs, format); };
void VisualMicroDebug::vmsetvar(char *rs, byte format, unsigned long &v) { v = vmstroul(rs, format); };

#if !defined(VM_DEBUG_EXCLUDE_TYPE_FLOAT)
void VisualMicroDebug::vmsetvar(char *rs, byte format, float &v) { v = (float)atof(rs); };
void VisualMicroDebug::vmsetvar(char *rs, byte format, double &v) { v = atof(rs); };
#endif

void VisualMicroDebug::vmsetvar(char *rs, byte format, char &v)
{
	vmsetvar(rs, format, (int8_t &)v);
}

void VisualMicroDebug::vmsetvar(char *rs, byte format, int8_t &v)
{
	/* removed 27.01.2015 HK as a bugfix
	if( format == 0 )	// treat as character, not as value
	v = *rs;
	else */
	v = (int8_t)vmstrtol(rs, format);
};
void VisualMicroDebug::vmsetvar(char *rs, byte format, uint8_t &v)
{
	int8_t c;
	vmsetvar(rs, format, c);
	v = (uint8_t)c;
}
void VisualMicroDebug::vmsetvar(char *rs, byte format, volatile uint8_t &v)
{
	int8_t c;
	vmsetvar(rs, format, c);
	v = (uint8_t)c;
}


//initialize debug object
VisualMicroDebug MicroDebug;


#pragma GCC diagnostic pop

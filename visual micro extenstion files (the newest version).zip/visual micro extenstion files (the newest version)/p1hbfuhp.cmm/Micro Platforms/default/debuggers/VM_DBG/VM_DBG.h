#ifndef _VM_DBG_h
#define _VM_DBG_h


//#define VM_DEBUG_USE_PRINT_F

/*
#define VM_DEBUG_ENABLE 1
#define _VM_DEBUG_BREAKPAUSE //300 bytes

#define VM_DEBUGGER_TYPE_HARDWARESERIAL 0
#define VM_DEBUGGER_TYPE_SOFTWARESERIAL 1
#define VM_DEBUGGER_TYPE_FASTSERIAL		2
#define VM_DEBUGGER_TYPE VM_DEBUGGER_TYPE_HARDWARESERIAL


#define _VM_DEBUG_AUTO_REPORTING //800 bytes
#if defined(_VM_DEBUG_AUTO_REPORTING)
#define _VM_DEBUG_READ_DIGITAL_PORTS _VM_DEBUG_ENABLE
#define _VM_DEBUG_READ_ANALOG_PINS _VM_DEBUG_ENABLE
#define _VM_DEBUG_I2C
#define _VM_DEBUG_READ_I2C_DEVICES _VM_DEBUG_ENABLE
#endif
*/

//#define VM_DEBUG_WRITEVARS_SIMPLE 1
#define VM_DEBUG_WRITEVARS_ADVANCED 1

#ifndef VM_DEBUG_WRITEVAR_CONFIRM
#define VM_DEBUG_WRITEVAR_CONFIRM 0
#endif

#ifndef _VM_DBG_
#define _VM_DBG_

#if defined(WIRING) && (WIRING >= 100)
#include "Wiring.h"
#elif defined(ARDUINO) && (ARDUINO >= 100)
//#include "variant.h"
#include "Arduino.h"
#else
#include "WProgram.h"
#endif



//#if defined(VM_DEBUGGER_TYPE) && VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_USBSERIAL
//	#include <USBSerial.h>
//#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NET_UDP)
#if ( defined(ESP32) || defined(ARDUINO_ARCH_ESP32) || defined(ESP8266) || defined(ARDUINO_ARCH_ESP8266) )	
#if defined(ESP8266)
#include <ESP8266WiFi.h> 
#else
#include <WiFi.h>
#endif
#include <WiFiUdp.h>
#endif
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NET_CONSOLE)
#include <Bridge.h>
#if ARDUINO >= 157
#include <BridgeServer.h>
#include <BridgeClient.h>
#else
#include <YunServer.h>
#include <YunClient.h>
#endif
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
#include <SoftwareSerial.h>
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_COSA)
#include "Cosa/UART.hh"
#include "Cosa/Types.h"
#include "Cosa/Bits.h"
#if defined(USBCON)
#include "Cosa/CDC.hh"
#endif
unsigned long millis();
typedef uint8_t byte;

#define VMDGB_HAS_READER


#endif

//#include <HardwareSerial.h>  
//#include "string.h"  
//#include <avr/pgmspace.h> 

#if defined(VM_DEBUG_AUTO_REPORTING)
#include "VM_Boards.h"
#endif

#if defined(VM_DEBUG_MEM_CHECK)
#include "VM_mem_check.h"
#endif


#if defined(VM_DEBUG_USE_PRINT_F)
	#include <stdarg.h>
#endif


#if (defined(VM_DBG_RT_ANALYTICS))
	#include "_dbg_pins.h"
#endif


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_GENERIC_OBJECT)

#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NO_SERIAL)
	#include "_dbg_fake_transport.h"
#endif


class VisualMicroDebug
{
private:
	bool tmp_found;
	bool ready_for_use; //network needs to be initialized before can be used otherwise esp8266 crashes
	unsigned long lastPacketMS;
	


#if VM_DEBUG_READ_I2C_DEVICES == 1
	bool devicesFound;
#endif

	//uint8_t missed_breakpoints[10];  //breakpoint id list: used to track global inits where serial was not available.
	//todo: change to using dynamic malloc and free in setup()
	//uint8_t missed_breakpoints_counter;
#if defined(VM_DEBUG_WRITEVARS_SIMPLE)||defined(VM_DEBUG_WRITEVARS_ADVANCED)
	uint8_t readVariableTextDataType();
	uint8_t readVariableTextLength();
#endif



public:
	//added mainly for cosa but let us have a special easily changble to rtc millis function :)
	unsigned long DBG_Millis();
	void DBG_YieldAndWait(unsigned long ms, bool handlEvents);
	void DBG_YieldAndWait(unsigned long ms);
	unsigned long BreakStartMillis;
	unsigned long BreakPrevMillis;
	unsigned long InBreakMsgRepeatMS;
	unsigned long InBreakMsgSent;
	bool alwaysBreak; //could be dangerous if true depending on application. user must switch on themselves. provide a warning!
	VisualMicroDebug();
	unsigned char read();
	unsigned char peek();
	uint8_t available();

	void OnBreakPointBegin(unsigned long iInBreakMsgRepeatMS);
	void OnBreakPointPrintBegin(uint8_t breakpoint_id);
	void OnBreakPointPrintEnd();
	void OnBreakPointEnd();
	void outPacketBeforePrint();
	bool outPacketStart(bool noWait);
	bool outPacketStart();
	void outPacketEnd();
	//
#if (defined(VM_DBG_RT_ANALYTICS))
	//ensure we are not optimized out as an object
	//todo: ensure pins code is highly optimized so the debugger doesn't try to step into it?
	//_dbg_pins * pins;
	_dbg_pins  pins();
#endif


// board specific
//

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == 	VM_DEBUGGER_TYPE_NET_UDP)
	IPAddress RemoteIP;
	WiFiUDP VM_DEBUG_UDP;
	WiFiUDP VM_DEBUG_UDP_READER;
	char readPacketBuffer[255];
	int readPacketSize; //size of pakcte in buffer (max 255)
	uint8_t readPacketNextCharIndex;
#endif

	//only required when write vars = true
	//used as temp holding/working for processing of breakpoints, avoids using memory for each bp

	uint8_t remoteCommand;
	uint8_t remoteCommandBpIndex;
	uint8_t remoteCommandVarIndex;
	char readString[40];




	/*
	#if defined(VM_DEBUGGER_TYPE) && VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_UART
	UARTClass *transport;
	void begin(UARTClass *theSerial);
	void begin(UARTClass *theSerial, long baud);
	#endif

	#if defined(VM_DEBUGGER_TYPE) && VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_USART
	USARTClass *transport;
	void begin(USARTClass *theSerial);
	void begin(USARTClass *theSerial, long baud);
	#endif
	*/



	//zero
#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_Uart)
	Uart *transport;
	void begin(Uart *theSerial);
	void begin(Uart *theSerial, unsigned long baud);
#endif



#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_GENERIC_OBJECT)
	//_dbg_fake_transportClass *transport;
	//VM_DEBUGGER_SOFT_TRANSPORT
	//void begin(unsigned long baud);
	void begin();
	void begin(unsigned long baud);
#endif


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NO_SERIAL)
	_dbg_fake_transportClass *transport;
	void begin(_dbg_fake_transportClass *theSerial);
	void begin(_dbg_fake_transportClass *theSerial, unsigned long baud);
#endif



#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_TEENSY)
	usb_serial_class *transport;
	void begin(usb_serial_class *theSerial);
	void begin(usb_serial_class *theSerial, unsigned long baud);
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == 	VM_DEBUGGER_TYPE_USBAPI)
	CDC *transport;
	void begin(CDC *theSerial);
	void begin(CDC *theSerial, unsigned long baud);
#endif



#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_MS430_SERIAL_)
//#if !defined(__MSP430_HAS_USCI__) && !defined(__MSP430_HAS_USCI_A0__) && !defined(__MSP430_HAS_USCI_A1__) && !defined(__MSP430_HAS_EUSCI_A0__)
	TimerSerial *transport;
	void begin(TimerSerial *theSerial);
	void begin(TimerSerial *theSerial, unsigned long baud);
//#else
//	Serial_ *transport;
//	void begin(Serial_ *theSerial);
//	void begin(Serial_ *theSerial, unsigned long baud);
//#endif
#endif


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_USB)
	Serial_ *transport;
	void begin(Serial_ *theSerial);
	void begin(Serial_ *theSerial, unsigned long baud);
#endif


	//DashPro	
#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SERIALUSB)
	SerialCDC *transport;
	void begin(SerialCDC *theSerial);
	void begin(SerialCDC *theSerial, unsigned long baud);
#endif



	//stm32/chipkit usb board on Serial
#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_USBSERIAL)
	USBSerial *transport;
	void begin(USBSerial *theSerial);
	void begin(USBSerial *theSerial, unsigned long baud);
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_HARDWARESERIAL1)
	HardwareSerial1 *transport;
	void begin(HardwareSerial1 *theSerial);
	void begin(HardwareSerial1 *theSerial, unsigned long baud);
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_HARDWARESERIAL2)
	HardwareSerial2 *transport;
	void begin(HardwareSerial2 *theSerial);
	void begin(HardwareSerial2 *theSerial, unsigned long baud);
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_HARDWARESERIAL3)
	HardwareSerial3 *transport;
	void begin(HardwareSerial3 *theSerial);
	void begin(HardwareSerial3 *theSerial, unsigned long baud);
#endif



#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_HARDWARESERIAL)

#if defined( DEFAULT_TO_TINY_DEBUG_SERIAL ) && DEFAULT_TO_TINY_DEBUG_SERIAL
	TinyDebugSerial *transport;
	void begin(TinyDebugSerial *theSerial);
	void begin(TinyDebugSerial *theSerial, long baud);
#else
	HardwareSerial *transport;
	void begin(HardwareSerial *theSerial);
	void begin(HardwareSerial *theSerial, unsigned long baud);
#endif
#endif

	//#if defined(VM_DEBUGGER_TYPE) && VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_USBSERIAL
	//	USBSerial *transport;  
	//	void begin(USBSerial *theSerial, unsigned long baud);
	//#endif



#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_COSA)
	//#undef VM_DEBUG_WRITEVARS_ADVANCED
	//#define VM_DEBUG_WRITEVARS_SIMPLE
	// Create an instance of the iostream and bind to the uart
	//IOStream Serial(&uart);
	// Start the uart
	//uart.begin(debug_speed);
	void init(unsigned long delayMs);
	IOStream *transport;

#if defined(USBCON)
	CDC *reader;
	void begin(CDC *theSerial, long unsigned int baud);
#else
	UART *reader;
	void begin(UART *theSerial, long unsigned int baud);
#endif

#else
	void init(unsigned long delayMs);
#endif

	uint32_t baudRate;


#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_CDCSerialClass)
	CDCSerialClass *transport;
	void begin(CDCSerialClass *theSerial, unsigned long baud);
#endif



#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_UART)
	UARTClass *transport;
	void begin(UARTClass *theSerial, unsigned long baud);
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == 	VM_DEBUGGER_TYPE_NET_UDP)
	WiFiUDP *transport;
	WiFiUDP *reader;
	void begin(WiFiUDP *theSerial, unsigned long baud);
#endif



#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_NET_CONSOLE)
	ConsoleClass *transport;
	void begin(ConsoleClass *theSerial, unsigned long baud);
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_TTYUART)
	TTYUARTClass *transport;
	void begin(TTYUARTClass *theSerial, unsigned long baud);
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_USART)
	USARTClass *transport;
	void begin(USARTClass *theSerial, unsigned long baud);
#endif

#if defined(VM_DEBUGGER_TYPE) && (VM_DEBUGGER_TYPE == VM_DEBUGGER_TYPE_SOFTWARESERIAL)
	SoftwareSerial *transport;
	void begin(SoftwareSerial *theSerial);
	void begin(SoftwareSerial *theSerial, unsigned long baud);
#endif

#if defined(VM_DEBUG_USE_PRINT_F)
	void p(char *fmt, ...);
#endif

	void sendMessage(const char debugger_message[]);
	void start(bool warnWait, bool alwaysBreak);

	//#if defined(_VM_DEBUG_BREAKPAUSE)
	uint8_t breakWait(uint8_t breakPointId);
	void sendContinuedACK(uint8_t breakPointId);
	//#endif


#if defined(VM_DEBUG_WRITEVARS_SIMPLE)
	char remoteVariableValue[20];
	void setVariable(int &i, int j);
	void setVariable(unsigned int &i, int j);
	void setVariable(unsigned long &i, int j);
	void setVariable(long &i, int j);
	void setVariable(float &i, int j);
#endif

#if defined(VM_DEBUG_WRITEVARS_ADVANCED)
	template<typename T> void setVariable(T i, long j);
	template<typename T> void setVariable(T &i, int j);
	template<typename T> void setVariable(T i, int format, long j);
	template<typename T> void setVariable(T &i, int format, int j);

	static void vmsetvar(char *rs, byte format, char *v);
	static void vmsetvar(char *rs, byte format, char &v);
	static void vmsetvar(char *rs, byte format, int8_t &v);
	static void vmsetvar(char *rs, byte format, uint8_t &v);
	static void vmsetvar(char *rs, byte format, volatile uint8_t &v);
	static void vmsetvar(char *rs, byte format, int16_t &v);
	static void vmsetvar(char *rs, byte format, uint16_t &v);
#if __SIZEOF_INT__ == __SIZEOF_LONG__
	// for 32 Bit CPUs
	static void vmsetvar(char *rs, byte format, int &v);
	static void vmsetvar(char *rs, byte format, unsigned int &v);
#endif
	static void vmsetvar(char *rs, byte format, long &v);
	static void vmsetvar(char *rs, byte format, unsigned long &v);
#if !defined(VM_DEBUG_EXCLUDE_TYPE_FLOAT)
	static void vmsetvar(char *rs, byte format, double &v);
	static void vmsetvar(char *rs, byte format, float &v);
#endif
	void no_lvalue_err();
	//void fetchVarData( char *buf );
	void fetchVarData();
	static byte whatbase(char *&rs);
	static unsigned long vmstroul(char *rs, byte format);
	static long vmstrtol(char *rs, byte format);
#endif


	//auto reporting
	//VM_DebugCommon_h
#if defined(VM_DEBUG_AUTO_REPORTING)
	//#include "VM_Boards.h"
#if VM_DEBUG_READ_DIGITAL_PORTS == 1
	void printPortsDigital(void);
#endif
#if VM_DEBUG_READ_ANALOG_PINS == 1
	void printPinsAnalog(void);
#endif
#if defined(VM_DEBUG_I2C)
	void initI2C(void);
#if VM_DEBUG_READ_I2C_DEVICES == 1
	void printI2CDeviceList(void);
#endif
#endif
#if VM_DEBUG_MEM_CHECK == 1
	void printFreeMemory(void);
	//unsigned long getFreeMemory(void);
#endif

#endif

};

extern VisualMicroDebug MicroDebug;
#endif




#if defined(VM_DEBUG_WRITEVARS_ADVANCED)
template<typename T>
void VisualMicroDebug::setVariable(T i, int format, long j)
{
	//#if defined(VM_DEBUG_WRITEVAR_CONFIRM)
	//transport->println("Set variable: ");
	//#endif

	//char readString[40];
	fetchVarData();
	//fetchVarData( readString );

	no_lvalue_err();
}

template<typename T>
void VisualMicroDebug::setVariable(T i, long j)
{
	setVariable(i, 0, j);
}

template<typename T>
void VisualMicroDebug::setVariable(T &i, int format, int j)
{
	//#if defined(VM_DEBUG_WRITEVAR_CONFIRM)
	//transport->println("fetch value=");
	//transport->println(i);
	//#endif
	//char readString[40];	
	//fetchVarData( readString );
	fetchVarData();

	vmsetvar(MicroDebug.readString, (byte)format, i);

#if VM_DEBUG_WRITEVAR_CONFIRM==1
	transport->print("value=");
	transport->print(i);
	transport->print("\r\n");
#else
	//value is not updated unless we have a slight pause
	//todo: investigate might be softwareserial related
	delay(10);
#endif
}

template<typename T>
void VisualMicroDebug::setVariable(T &i, int j)
{
	setVariable(i, (byte)0, j);
}
#endif

#endif
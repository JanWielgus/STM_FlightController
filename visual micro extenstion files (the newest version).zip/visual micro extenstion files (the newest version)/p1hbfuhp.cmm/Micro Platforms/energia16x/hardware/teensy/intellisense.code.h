#define __AVR__
#define __extension__
#define  __attribute__(x)
typedef void *__builtin_va_list;

#define __extension__
#define __ATTR_PURE__
#define __ATTR_CONST__
#define __inline__
#define __asm__ 
#define __volatile__

#define NEW_H

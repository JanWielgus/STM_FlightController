
#define __inline__
#define __asm__(x)
#define __asm__(char)
#define __extension__
#define __ATTR_PURE__
#define __ATTR_CONST__
#define __inline__
#define __volatile__


#define __attribute__(x)
#define __LANGUAGE_C_PLUS_PLUS

typedef void *__builtin_va_list;

typedef unsigned char byte;
extern "C" void __cxa_pure_virtual() { ; }
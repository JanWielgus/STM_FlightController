#define __inline__
#define __asm__(x)
#define __attribute__(x)
#define __extension__
#define __ATTR_PURE__
#define __ATTR_CONST__
#define __inline__
#define __volatile__

#define __ASM
#define __INLINE
#define __GNUC__ 4
#define __GNUC_MINOR__ 100

#define __ICCARM__
#define __ARMCC_VERSION 400678

//#define __STDC_VERSION__ 199901L
//#define __STRICT_ANSI__
#define _XKEYCHECK_H
#define TC_INST_NUM 1
#define TCC_INST_NUM 1
#define __IAR_SYSTEMS_ASM__
#define __ASSEMBLY__

#define __int_least8_t_defined (x)
#define __int_least16_t_defined (x)
#define __int_least32_t_defined (x)


typedef char int8_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef short int16_t;
typedef unsigned long uint32_t;
typedef long int32_t;
typedef int __builtin_va_list;

#define prog_void
#define PGM_VOID_P int
            
typedef unsigned char byte;
extern "C" void __cxa_pure_virtual() {;}



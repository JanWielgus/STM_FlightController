#define __ARM__
#define __arm__
#define __inline__
#define __asm__(x)
#define __extension__
#define __ATTR_PURE__
#define __ATTR_CONST__
#define __inline__
#define __volatile__
#define _HAVE_STDC

#define __ASM
#define __INLINE
#define __builtin_va_list void

#define __attribute__(noinline)


typedef unsigned char byte;
extern "C" void __cxa_pure_virtual() { ; }

#include "sam3xa.h"
#define __ARM__
#define __arm__
#define __inline__
#define __asm__(x)
#define __attribute__(x)
#define __extension__
#define __ATTR_PURE__
#define __ATTR_CONST__
#define __inline__
#define __asm__ 
#define asm
#define __volatile__


#define __ASM
#define __INLINE
#define __builtin_va_list void
#define _GNU_SOURCE 3
#define __GNUC__ 6
#define  __GNUC_MINOR__ 3
#define  __GNUC_PATCHLEVEL__ 0


#define __GNU__

#define __INT32_TYPE__ 4
#define __INTPTR_TYPE__ 4

typedef __uint32_t unsigned long;
typedef __int32_t long;
typedef __uintptr_t unsigned long;
typedef __intptr_t long;

typedef uint8_t boolean;
typedef uint32_t unsigned long;
typedef int32_t long;

typedef uint8_t boolean;

#define prog_void
#define PGM_VOID_P int
            
typedef unsigned char byte;
extern "C" void __cxa_pure_virtual() {;}



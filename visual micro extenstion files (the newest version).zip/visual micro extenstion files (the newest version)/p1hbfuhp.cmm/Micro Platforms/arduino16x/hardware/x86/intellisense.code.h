#define __inline__
#define __asm__(x)
#define __extension__
#define __ATTR_PURE__
#define __ATTR_CONST__
#define __inline__
#define __asm__ 
#define __volatile__

//#define __ICCARM__
#define __ASM
#define __INLINE
#define __builtin_va_list char[]
#define __gnuc_va_list char[]
#define __arg 
#define __attribute__(noinline)


#define __GNUC__ 0
#define __attribute__(noinline)

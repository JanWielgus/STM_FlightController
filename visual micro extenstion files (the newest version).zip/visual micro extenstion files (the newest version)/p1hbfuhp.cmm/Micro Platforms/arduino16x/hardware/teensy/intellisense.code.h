#define __AVR__
#define __extension__
#define  __attribute__(x)
typedef void *__builtin_va_list;

#define __extension__
#define __ATTR_PURE__
#define __ATTR_CONST__
#define __inline__
#define __asm__ 
#define __volatile__

#define NEW_H
// C:\TESTBED\arduino\ide_1-8-8\hardware\tools\arm\arm-none-eabi\include\sys\types.h

typedef signed char        int8_t;
typedef short              int16_t;
typedef int                int32_t;
typedef long long          int64_t;
typedef unsigned char      uint8_t;
typedef unsigned short     uint16_t;
typedef unsigned int       uint32_t;
typedef unsigned long long uint64_t;
typedef unsigned char boolean;
typedef unsigned char byte;
typedef unsigned int uint;

// Defines all pins from 
//C:\TESTBED\arduino\ide_1-8-8\hardware\teensy\avr\cores\teensy\pins_arduino.h
#define __AVR_ATmega32U4__

// C:\TESTBED\arduino\ide_1-8-8\hardware\teensy\avr\cores\teensy\wiring.h
#define sei()
#define cli()
#define interrupts() sei()
#define noInterrupts() cli()

// C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\VC\Tools\MSVC\14.21.27702\include\stdint.h
typedef unsigned char      uint8_t;


#define __ARM__
#define __arm__
#define __inline__
#define __asm__(x)
#define __attribute__(x)
#define __extension__

typedef int __builtin_va_list;
#define __STATIC_INLINE static inline
#define __ASSEMBLY__
#define __INLINE
#undef _WIN32
#define __GNUC__ 1
//#define __ICCARM__
//define __ARMCC_VERSION 6010050
#define __builtin_offsetof //(TYPE, int) 
#define SVCALL(SD_MUTEX_NEW, uint32_t, nrf_mutex_t);
#define _GCC_LIMITS_H_

//adafruit
typedef long __SIZE_TYPE__;
typedef long __INTPTR_TYPE__;

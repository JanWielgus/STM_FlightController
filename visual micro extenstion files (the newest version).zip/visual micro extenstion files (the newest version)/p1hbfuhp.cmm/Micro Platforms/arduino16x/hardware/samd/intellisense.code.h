//#define __GNUC__ 2
#define _Pragma(x)
#define __ARMCC_VERSION 6010050

#define __PTRDIFF_TYPE__ int
#define __ARM__
#define __arm__
#define always_inline
#define __inline__
#define __asm__(x)
#define __attribute__(x)
#define __extension__
#define __ATTR_PURE__
#define __ATTR_CONST__
#define __inline__
#define __volatile__
typedef int __SIZE_TYPE__;
typedef int __builtin_va_list;
typedef int __builtin_arm_nop;
typedef int __builtin_arm_wfi;
typedef int __builtin_arm_wfe;
typedef int __builtin_arm_sev;
typedef int __builtin_arm_isb;
typedef int __builtin_arm_dsb;
typedef int __builtin_arm_dmb;
typedef int __builtin_bswap32;
typedef int __builtin_bswap16;
#define _Pragma(x)
#define __ASM
#define __INLINE

#include "samd.h"
//#include "samd21/include/samd21.h"



#undef __cplusplus
#define __cplusplus 201103L


#define __arm__
#define __ARM__
#define  __attribute__(x)
typedef void *__builtin_va_list;
#define __extension__
#define __ATTR_PURE__
#define __ATTR_CONST__
#define __inline__
#define __asm__(x)
#define __volatile__
#define NEW_H
#undef _WIN32
#define __STDC__ 
#define __GNUC__ 2
#define __GNUC_MINOR__ 5

extern int at_quick_exit(void (*f)(void));
int at_quick_exit(void (*f)(void)) {
}
extern int quick_exit(void (*f)(void));
int quick_exit(void (*f)(void)) {
}



#define __INT64_TYPE__ 8
#define __INTPTR_TYPE__ 4
#define __INT32_TYPE__ 4

typedef long intptr_t;
typedef long __intptr_t;
typedef unsigned long __uintptr_t;
typedef long __int32_t;
typedef unsigned long __uint32_t;
typedef unsigned short  __uint16_t;
typedef short __int16_t;
typedef unsigned short  __uint8_t;
typedef short __int8_t;
typedef unsigned long __uint64_t;
typedef double __int64_t;
typedef unsigned long uint64_t;
typedef double int64_t;
typedef unsigned short uint8_t;
typedef short int8_t;

typedef unsigned int uint16_t;
typedef short int16_t;
typedef long __int32_t;
typedef unsigned long __uint32_t;

#define at_quick_exit(x)

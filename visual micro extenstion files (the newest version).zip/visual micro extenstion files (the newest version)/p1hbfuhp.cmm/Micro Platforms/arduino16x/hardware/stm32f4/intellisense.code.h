#define __inline__
#define __asm__(x)
#define __extension__
#define __ATTR_PURE__
#define __ATTR_CONST__
#define __inline__
#define __volatile__


//#define __ICCARM__
#define __ASM
#define __INLINE
#define __builtin_va_list void
//#define _GNU_SOURCE 
#define __GNUC__ 3
//#undef  __ICCARM__
//#define __GNU__

#define __ARMCC_VERSION 400678
#define __attribute__(noinline)

#define prog_void
#define PGM_VOID_P int

            
typedef unsigned char byte;
extern "C" void __cxa_pure_virtual() {;}



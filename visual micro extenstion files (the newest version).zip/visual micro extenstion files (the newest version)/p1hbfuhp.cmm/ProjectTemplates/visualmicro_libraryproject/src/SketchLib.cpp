/*
 Name:		$safeitemname$.cpp
 Created:	$time$
 Author:	$username$
 Editor:	http://www.visualmicro.com
*/

#include "$safeprojectname$.h"



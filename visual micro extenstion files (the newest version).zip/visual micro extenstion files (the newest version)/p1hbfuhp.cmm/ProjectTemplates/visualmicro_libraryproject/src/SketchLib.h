/*
 Name:		$safeitemname$.h
 Created:	$time$
 Author:	$username$
 Editor:	http://www.visualmicro.com
*/

#ifndef _$safeitemname$_h
#define _$safeitemname$_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif


#endif

